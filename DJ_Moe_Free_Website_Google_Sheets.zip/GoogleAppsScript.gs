function doPost(e) {
  const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName("Bookings")
    || SpreadsheetApp.getActiveSpreadsheet().insertSheet("Bookings");

  const data = JSON.parse(e.postData.contents);

  if (sheet.getLastRow() === 0) {
    sheet.appendRow([
      "Submitted At","Full Name","Email","Phone","Event Date","Event Type",
      "Venue / City","Guest Count","Start Time","End Time","Event Details"
    ]);
  }

  sheet.appendRow([
    new Date(),
    data.name || "",
    data.email || "",
    data.phone || "",
    data.date || "",
    data.type || "",
    data.venue || "",
    data.guests || "",
    data.start || "",
    data.end || "",
    data.details || ""
  ]);

  return ContentService
    .createTextOutput(JSON.stringify({ok:true}))
    .setMimeType(ContentService.MimeType.JSON);
}

function doGet() {
  return ContentService
    .createTextOutput("DJ Moe booking endpoint is live.")
    .setMimeType(ContentService.MimeType.TEXT);
}
