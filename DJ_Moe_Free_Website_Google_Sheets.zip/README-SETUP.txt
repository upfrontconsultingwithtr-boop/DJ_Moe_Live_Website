DJ MOE WEBSITE — FREE DEPLOYMENT

Included:
- index.html
- dj-moe.jpg
- GoogleAppsScript.gs

Recommended free setup:
1. Create a Google Sheet named "DJ Moe Bookings".
2. In Google Sheets: Extensions > Apps Script.
3. Paste the contents of GoogleAppsScript.gs and save.
4. Deploy > New deployment > Web app.
5. Execute as: Me.
6. Who has access: Anyone.
7. Copy the Web app URL.
8. Open index.html and replace:
   PASTE_YOUR_GOOGLE_APPS_SCRIPT_WEB_APP_URL_HERE
   with your Web app URL.
9. Upload index.html and dj-moe.jpg to a free static host such as GitHub Pages or Netlify.
10. Use the free host subdomain (for example, yourname.github.io or yoursite.netlify.app).

IMPORTANT:
- A truly free "domain" normally means a free hosting subdomain. A custom .com domain is generally not free.
- The Google Sheet must be owned by an account that can authorize the Apps Script.
- Test the form after publishing.
